package com.gamehub.gamex

import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.os.Build

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GameHubApp() }
    }
}

@Composable
fun GameHubApp() {
    val context = LocalContext.current
    val configManager = remember { ConfigManager(context) }
    val scanner = remember { GameScanner(context) }

    var loadResult by remember { mutableStateOf(configManager.load()) }

    loadResult.fold(
        onSuccess = { cfg -> MaterialTheme(colorScheme = darkScheme(cfg)) { MainScaffold(cfg, configManager, scanner, onReload = { loadResult = configManager.load() }) } },
        onFailure = { err ->
            MaterialTheme(colorScheme = darkScheme(null)) {
                ConfigErrorScreen(
                    message = err.message ?: "Config tidak valid",
                    onReset = { loadResult = configManager.resetToDefault() }
                )
            }
        }
    )
}

private fun darkScheme(cfg: GameHubConfig?): ColorScheme {
    val accent = cfg?.accent?.let { Color(android.graphics.Color.parseColor(it)) } ?: Color(0xFFFF1744)
    val secondary = cfg?.secondary?.let { Color(android.graphics.Color.parseColor(it)) } ?: Color(0xFF9C27B0)
    val highlight = cfg?.highlight?.let { Color(android.graphics.Color.parseColor(it)) } ?: Color(0xFFFF4081)
    return darkColorScheme(
        primary = accent,
        secondary = secondary,
        tertiary = highlight,
        background = Color.Black,
        surface = Color(0xFF121212),
        onBackground = Color.White,
        onSurface = Color.White,
        onPrimary = Color.White
    )
}

@Composable
fun MainScaffold(
    cfg: GameHubConfig,
    configManager: ConfigManager,
    scanner: GameScanner,
    onReload: () -> Unit
) {
    var page by remember { mutableStateOf(cfg.navigation.first()) }
    val context = LocalContext.current

    Box(Modifier.fillMaxSize()) {
        WallpaperBackground(cfg)

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavBar(cfg.navigation, page) { page = it }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                val content: @Composable (String) -> Unit = { name ->
                    when (name) {
                        "Home" -> HomePage(cfg, scanner)
                        "Library" -> LibraryPage(cfg, scanner)
                        "Performance" -> PerformancePage(cfg)
                        "Settings" -> SettingsPage(cfg, configManager, onReload)
                    }
                }
                if (cfg.animation) {
                    Crossfade(targetState = page, label = "page") { content(it) }
                } else {
                    content(page)
                }
            }
        }
    }
}

@Composable
private fun WallpaperBackground(cfg: GameHubConfig) {
    val context = LocalContext.current
    val bitmap = remember(cfg.backgroundImage) {
        runCatching {
            context.assets.open(cfg.backgroundImage).use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        bitmap?.let {
            val imgModifier = if (cfg.blur && Build.VERSION.SDK_INT >= 31) Modifier.fillMaxSize().blur(12.dp) else Modifier.fillMaxSize()
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = imgModifier
            )
        }
        // dark overlay sesuai background.overlay
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = cfg.overlay)))
        // kilau ungu-pink dari secondary/highlight
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.6f)))
            )
        )
    }
}

/** Kartu kaca (glassmorphism) yang bentuknya mengikuti ui.rounded_corners dan ui.corner_radius. */
@Composable
fun GlassCard(cfg: GameHubConfig, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = if (cfg.roundedCorners) RoundedCornerShape(cfg.cornerRadius.dp) else RoundedCornerShape(0.dp)
    Column(
        modifier = modifier
            .clip(shape)
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun NavBar(items: List<String>, selected: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Color.Black.copy(alpha = 0.7f)) {
        items.forEach { name ->
            NavigationBarItem(
                selected = name == selected,
                onClick = { onSelect(name) },
                icon = { Text(name.first().toString(), fontWeight = FontWeight.Bold) },
                label = { Text(name) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                )
            )
        }
    }
}

@Composable
private fun HomePage(cfg: GameHubConfig, scanner: GameScanner) {
    val context = LocalContext.current
    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { scanner.installApk(it) }
    }
    val installed = remember { scanner.installedGames() }
    val recent = remember { scanner.recentlyPlayed().mapNotNull { pkg -> installed.find { it.packageName == pkg } } }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("GameHub GameX", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
        }
        if (cfg.feature("apk_picker")) {
            item {
                GlassCard(cfg) {
                    Text("Pasang APK", fontWeight = FontWeight.SemiBold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { pickApk.launch(arrayOf("application/vnd.android.package-archive")) }) {
                        Text("Pilih file APK")
                    }
                }
            }
        }
        if (cfg.feature("recently_played")) {
            item { SectionTitle("Terakhir dimainkan") }
            if (recent.isEmpty()) {
                item { Text("Belum ada game yang dimainkan.", color = Color.White.copy(alpha = 0.7f)) }
            } else {
                items(recent, key = { it.packageName }) { game ->
                    GameRow(cfg, game) { if (cfg.feature("game_launcher")) scanner.launch(game.packageName) }
                }
            }
        }
    }
}

@Composable
private fun LibraryPage(cfg: GameHubConfig, scanner: GameScanner) {
    var query by remember { mutableStateOf("") }
    var games by remember { mutableStateOf<List<GameEntry>>(emptyList()) }
    LaunchedEffect(Unit) {
        games = withContext(Dispatchers.Default) { if (cfg.feature("game_detection")) scanner.installedGames() else emptyList() }
    }
    val filtered = games.filter { it.label.contains(query, ignoreCase = true) }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Library", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Cari game") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (!cfg.feature("game_detection")) {
            item { Text("Deteksi game dimatikan di gamehub.yml", color = Color.White.copy(alpha = 0.7f)) }
        }
        items(filtered, key = { it.packageName }) { game ->
            GameRow(cfg, game) { if (cfg.feature("game_launcher")) scanner.launch(game.packageName) }
        }
        if (games.isNotEmpty() && filtered.isEmpty()) {
            item { Text("Tidak ada game yang cocok.", color = Color.White.copy(alpha = 0.7f)) }
        }
    }
}

@Composable
private fun GameRow(cfg: GameHubConfig, game: GameEntry, onLaunch: () -> Unit) {
    GlassCard(cfg, Modifier.fillMaxWidth().clickable { onLaunch() }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(game.label, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (game.isGameCategory) "Game" else game.packageName,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Button(onClick = onLaunch) { Text("Launch") }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
}

@Composable
private fun PerformancePage(cfg: GameHubConfig) {
    val context = LocalContext.current
    var snap by remember { mutableStateOf<SystemSnapshot?>(null) }

    LaunchedEffect(cfg.pollIntervalMs) {
        while (true) {
            snap = withContext(Dispatchers.Default) { SystemInfo.snapshot(context) }
            delay(cfg.pollIntervalMs)
        }
    }

    val s = snap
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Performance", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
        if (s == null) {
            Text("Membaca data sistem...", color = Color.White.copy(alpha = 0.7f))
            return@Column
        }
        if (cfg.feature("ram_monitor")) {
            StatCard(cfg, "RAM", "${s.ramUsedMb} / ${s.ramTotalMb} MB", s.ramUsedMb.toFloat() / s.ramTotalMb.coerceAtLeast(1))
        }
        if (cfg.feature("cpu_monitor")) {
            StatCard(cfg, "CPU", "${s.cpuModel}\n${s.cpuCores} core" + (s.cpuMaxMhz?.let { " • max $it MHz" } ?: ""), null)
        }
        if (cfg.feature("storage_monitor")) {
            StatCard(
                cfg, "Storage",
                "%.1f / %.1f GB".format(s.storageUsedGb, s.storageTotalGb),
                (s.storageUsedGb / s.storageTotalGb.coerceAtLeast(0.1)).toFloat()
            )
        }
        if (cfg.feature("battery_monitor")) {
            val temp = s.batteryTempC?.let { " • %.1f°C".format(it) } ?: ""
            StatCard(
                cfg, "Baterai",
                "${s.batteryPercent}%" + (if (s.batteryCharging) " (mengisi)" else "") + temp,
                s.batteryPercent / 100f
            )
        }
        if (cfg.refreshRateMonitor) {
            StatCard(cfg, "Refresh rate", "%.0f Hz".format(s.refreshRateHz), null)
        }
    }
}

@Composable
private fun StatCard(cfg: GameHubConfig, title: String, value: String, progress: Float?) {
    GlassCard(cfg, Modifier.fillMaxWidth()) {
        Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.tertiary)
        Spacer(Modifier.height(4.dp))
        Text(value, color = Color.White, fontSize = 16.sp)
        if (progress != null) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun SettingsPage(cfg: GameHubConfig, configManager: ConfigManager, onReload: () -> Unit) {
    val context = LocalContext.current
    var text by remember { mutableStateOf(configManager.currentText()) }
    var message by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        configManager.importFrom(uri)
            .onSuccess { text = configManager.currentText(); message = "Import berhasil"; onReload() }
            .onFailure { message = it.message }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/x-yaml")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        configManager.exportTo(uri)
            .onSuccess { message = "Export berhasil" }
            .onFailure { message = it.message }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
        GlassCard(cfg, Modifier.fillMaxWidth()) {
            Text("gamehub.yml", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.tertiary)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth().height(320.dp),
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                keyboardOptions = KeyboardOptions.Default
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    configManager.save(text)
                        .onSuccess { message = "Tersimpan dan valid"; onReload() }
                        .onFailure { message = it.message }
                }) { Text("Validasi & Simpan") }
                OutlinedButton(onClick = {
                    configManager.resetToDefault()
                        .onSuccess { text = configManager.currentText(); message = "Dikembalikan ke default"; onReload() }
                        .onFailure { message = it.message }
                }) { Text("Reset") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Import") }
                OutlinedButton(onClick = { exportLauncher.launch(ConfigManager.FILE_NAME) }) { Text("Export") }
            }
            message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.tertiary)
            }
        }
        GlassCard(cfg, Modifier.fillMaxWidth()) {
            Text("Izin instal APK", fontWeight = FontWeight.SemiBold, color = Color.White)
            Text("Agar bisa memasang APK dari app ini, izinkan 'Install unknown apps'.", color = Color.White.copy(alpha = 0.7f))
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { GameScanner(context).openInstallPermissionSettings() }) { Text("Buka pengaturan") }
        }
        Text("Versi ${cfg.appVersion} • ${cfg.appName}", color = Color.White.copy(alpha = 0.5f), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ConfigErrorScreen(message: String, onReset: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black).padding(16.dp), contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.08f))
                .border(1.dp, Color(0xFFFF1744).copy(alpha = 0.45f), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Text("gamehub.yml tidak valid", fontWeight = FontWeight.Bold, color = Color(0xFFFF1744), style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.White)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onReset) { Text("Pakai config default") }
        }
    }
}
