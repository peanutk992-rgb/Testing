package com.gamehub.gamex

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File

data class SystemSnapshot(
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val cpuCores: Int,
    val cpuModel: String,
    val cpuMaxMhz: Long?,
    val storageUsedGb: Double,
    val storageTotalGb: Double,
    val batteryPercent: Int,
    val batteryCharging: Boolean,
    val batteryTempC: Double?,
    val refreshRateHz: Float
)

/** Membaca info RAM, CPU, storage, baterai, dan refresh rate tanpa root atau Shizuku. */
object SystemInfo {

    fun snapshot(context: Context): SystemSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val totalMb = mi.totalMem / (1024 * 1024)
        val usedMb = (mi.totalMem - mi.availMem) / (1024 * 1024)

        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes.toDouble()
        val free = stat.availableBytes.toDouble()

        val battery = batteryInfo(context)

        return SystemSnapshot(
            ramUsedMb = usedMb,
            ramTotalMb = totalMb,
            cpuCores = Runtime.getRuntime().availableProcessors(),
            cpuModel = cpuModel(),
            cpuMaxMhz = cpuMaxMhz(),
            storageUsedGb = (total - free) / GB,
            storageTotalGb = total / GB,
            batteryPercent = battery.first,
            batteryCharging = battery.second,
            batteryTempC = battery.third,
            refreshRateHz = refreshRate(context)
        )
    }

    private const val GB = 1024.0 * 1024.0 * 1024.0

    private fun batteryInfo(context: Context): Triple<Int, Boolean, Double?> {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }?.let { it / 10.0 }
        return Triple(pct.coerceIn(0, 100), charging, temp)
    }

    @Suppress("DEPRECATION")
    private fun refreshRate(context: Context): Float {
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                context.display?.refreshRate ?: 60f
            } else {
                (context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager)
                    .defaultDisplay.refreshRate
            }
        } catch (e: Exception) {
            60f
        }
    }

    private fun cpuModel(): String {
        val hardware = Build.HARDWARE.takeIf { it.isNotBlank() } ?: Build.BOARD
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        return "$hardware ($abi)"
    }

    /** Frekuensi maksimum CPU dari sysfs; beberapa HP membatasi akses, jadi bisa null. */
    private fun cpuMaxMhz(): Long? = try {
        File("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq")
            .readText().trim().toLong() / 1000
    } catch (e: Exception) {
        null
    }
}
