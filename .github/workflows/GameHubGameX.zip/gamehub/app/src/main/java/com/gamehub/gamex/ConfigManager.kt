package com.gamehub.gamex

import android.content.Context
import android.net.Uri
import org.snakeyaml.engine.v2.api.DumpSettings
import org.snakeyaml.engine.v2.api.Dump
import org.snakeyaml.engine.v2.api.Load
import org.snakeyaml.engine.v2.api.LoadSettings
import org.snakeyaml.engine.v2.common.FlowStyle
import java.io.File

class ConfigException(message: String) : Exception(message)

data class GameHubConfig(
    val appName: String,
    val appVersion: String,
    val theme: String,
    val backgroundImage: String,
    val backgroundFullscreen: Boolean,
    val overlay: Float,
    val blur: Boolean,
    val style: String,
    val accent: String,
    val secondary: String,
    val highlight: String,
    val animation: Boolean,
    val roundedCorners: Boolean,
    val cornerRadius: Int,
    val navigation: List<String>,
    val features: Map<String, Boolean>,
    val rootRequired: Boolean,
    val shizukuRequired: Boolean,
    val refreshRateMonitor: Boolean,
    val pollIntervalMs: Long,
    val raw: Map<String, Any?>
) {
    fun feature(name: String) = features[name] ?: false

    companion object {
        val PAGES = setOf("Home", "Library", "Performance", "Settings")
        private val HEX = Regex("^#[0-9A-Fa-f]{6}$")

        /** Parse + validate. Throws ConfigException with a readable message. */
        fun parse(text: String): GameHubConfig {
            val root: Any? = try {
                Load(LoadSettings.builder().build()).loadFromString(text)
            } catch (e: Exception) {
                throw ConfigException("YAML tidak valid: ${e.message?.lineSequence()?.firstOrNull() ?: "format salah"}")
            }
            val map = root as? Map<*, *> ?: throw ConfigException("YAML harus berupa daftar key: value di level atas")

            fun section(name: String): Map<*, *> =
                (map[name] as? Map<*, *>) ?: throw ConfigException("Bagian '$name' tidak ditemukan atau salah format")

            fun str(s: Map<*, *>, path: String, key: String, default: String? = null): String {
                val v = s[key] ?: default ?: throw ConfigException("'$path.$key' wajib diisi")
                return v.toString()
            }

            fun bool(s: Map<*, *>, path: String, key: String, default: Boolean): Boolean {
                val v = s[key] ?: return default
                return v as? Boolean ?: throw ConfigException("'$path.$key' harus true/false")
            }

            fun color(s: Map<*, *>, path: String, key: String, default: String): String {
                val v = str(s, path, key, default)
                if (!HEX.matches(v)) throw ConfigException("'$path.$key' harus format hex seperti #FF1744")
                return v
            }

            val app = section("app")
            val bg = section("background")
            val ui = section("ui")
            val perf = (map["performance"] as? Map<*, *>) ?: emptyMap<Any, Any>()
            val feat = (map["features"] as? Map<*, *>) ?: emptyMap<Any, Any>()

            val overlay = (bg["overlay"] ?: 0.45).toString().toFloatOrNull()
                ?: throw ConfigException("'background.overlay' harus angka 0.0 - 1.0")
            if (overlay !in 0f..1f) throw ConfigException("'background.overlay' harus di antara 0.0 dan 1.0")

            val radius = (ui["corner_radius"] ?: 20).toString().toIntOrNull()
                ?: throw ConfigException("'ui.corner_radius' harus angka")
            if (radius !in 0..64) throw ConfigException("'ui.corner_radius' harus 0 - 64")

            val nav = (map["navigation"] as? List<*>)?.map { it.toString() }
                ?: listOf("Home", "Library", "Performance", "Settings")
            if (nav.isEmpty()) throw ConfigException("'navigation' tidak boleh kosong")
            nav.firstOrNull { it !in PAGES }?.let {
                throw ConfigException("Halaman '$it' tidak dikenal. Pilihan: ${PAGES.joinToString()}")
            }

            val poll = (perf["poll_interval_ms"] ?: 1000).toString().toLongOrNull()
                ?: throw ConfigException("'performance.poll_interval_ms' harus angka")
            if (poll < 250) throw ConfigException("'performance.poll_interval_ms' minimal 250")

            val features = listOf(
                "game_detection", "game_launcher", "recently_played", "apk_picker",
                "ram_monitor", "cpu_monitor", "storage_monitor", "battery_monitor"
            ).associateWith { bool(feat, "features", it, true) }

            return GameHubConfig(
                appName = str(app, "app", "name", "GameHub GameX"),
                appVersion = str(app, "app", "version", "1.0.0"),
                theme = str(app, "app", "theme", "dark"),
                backgroundImage = str(bg, "background", "image", "sparkler.png"),
                backgroundFullscreen = bool(bg, "background", "fullscreen", true),
                overlay = overlay,
                blur = bool(bg, "background", "blur", false),
                style = str(ui, "ui", "style", "glassmorphism"),
                accent = color(ui, "ui", "accent", "#FF1744"),
                secondary = color(ui, "ui", "secondary", "#9C27B0"),
                highlight = color(ui, "ui", "highlight", "#FF4081"),
                animation = bool(ui, "ui", "animation", true),
                roundedCorners = bool(ui, "ui", "rounded_corners", true),
                cornerRadius = radius,
                navigation = nav,
                features = features,
                rootRequired = bool(perf, "performance", "root_required", false),
                shizukuRequired = bool(perf, "performance", "shizuku_required", false),
                refreshRateMonitor = bool(perf, "performance", "refresh_rate_monitor", true),
                pollIntervalMs = poll,
                raw = map.entries.associate { it.key.toString() to it.value }
            )
        }
    }
}

/** Menyimpan, memuat, meng-import, dan meng-export gamehub.yml. */
class ConfigManager(private val context: Context) {

    private val file: File get() = File(context.filesDir, FILE_NAME)

    /** Muat config lokal; kalau belum ada, salin default dari assets. */
    fun load(): Result<GameHubConfig> = runCatching {
        if (!file.exists()) {
            val defaultText = context.assets.open(FILE_NAME).bufferedReader().use { it.readText() }
            file.writeText(defaultText)
        }
        GameHubConfig.parse(file.readText())
    }

    /** Teks YAML yang sedang aktif (dipakai editor di Settings). */
    fun currentText(): String =
        if (file.exists()) file.readText()
        else context.assets.open(FILE_NAME).bufferedReader().use { it.readText() }

    fun loadDefault(): GameHubConfig =
        GameHubConfig.parse(context.assets.open(FILE_NAME).bufferedReader().use { it.readText() })

    /** Validasi lalu simpan teks YAML ke penyimpanan lokal. */
    fun save(text: String): Result<GameHubConfig> = runCatching {
        val cfg = GameHubConfig.parse(text)
        file.writeText(text)
        cfg
    }

    fun importFrom(uri: Uri): Result<GameHubConfig> = runCatching {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: throw ConfigException("File tidak bisa dibaca")
        save(text).getOrThrow()
    }

    fun exportTo(uri: Uri): Result<Unit> = runCatching {
        val text = if (file.exists()) file.readText() else dumpConfig(loadDefault().raw)
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(text) }
            ?: throw ConfigException("Tujuan export tidak bisa ditulis")
    }

    /** Ubah satu nilai lalu simpan (dipakai dari layar Settings). */
    fun updateValue(section: String, key: String, value: Any): Result<GameHubConfig> = runCatching {
        val current = GameHubConfig.parse(if (file.exists()) file.readText() else dumpConfig(loadDefault().raw))
        val root = current.raw.toMutableMap()
        val sec = ((root[section] as? Map<*, *>) ?: emptyMap<Any, Any>()).entries
            .associate { it.key.toString() to it.value }.toMutableMap()
        sec[key] = value
        root[section] = sec
        save(dumpConfig(root)).getOrThrow()
    }

    fun resetToDefault(): Result<GameHubConfig> = runCatching {
        val text = context.assets.open(FILE_NAME).bufferedReader().use { it.readText() }
        save(text).getOrThrow()
    }

    companion object {
        const val FILE_NAME = "gamehub.yml"

        fun dumpConfig(data: Map<String, Any?>): String {
            val settings = DumpSettings.builder().setDefaultFlowStyle(FlowStyle.BLOCK).build()
            return Dump(settings).dumpToString(data)
        }
    }
}
