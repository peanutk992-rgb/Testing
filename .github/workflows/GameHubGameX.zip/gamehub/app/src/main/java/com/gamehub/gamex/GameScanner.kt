package com.gamehub.gamex

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.edit

data class GameEntry(
    val packageName: String,
    val label: String,
    val isGameCategory: Boolean
)

/** Deteksi game yang terpasang, peluncuran game, dan daftar recently played. */
class GameScanner(private val context: Context) {

    private val prefs = context.getSharedPreferences("gamehub_state", Context.MODE_PRIVATE)
    private val pm: PackageManager get() = context.packageManager

    /** Semua app yang punya launcher icon; game dengan kategori GAME ditandai. */
    fun installedGames(): List<GameEntry> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcherIntent, 0)
            .asSequence()
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .map { info ->
                GameEntry(
                    packageName = info.packageName,
                    label = pm.getApplicationLabel(info).toString(),
                    isGameCategory = isGame(info)
                )
            }
            .sortedWith(compareByDescending<GameEntry> { it.isGameCategory }.thenBy { it.label.lowercase() })
            .toList()
    }

    private fun isGame(info: ApplicationInfo): Boolean {
        if (info.category == ApplicationInfo.CATEGORY_GAME) return true
        @Suppress("DEPRECATION")
        return (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
    }

    fun launch(packageName: String): Boolean {
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        markPlayed(packageName)
        return true
    }

    fun markPlayed(packageName: String) {
        val current = recentlyPlayed().filter { it != packageName }
        val updated = (listOf(packageName) + current).take(MAX_RECENT)
        prefs.edit { putString(KEY_RECENT, updated.joinToString(",")) }
    }

    fun recentlyPlayed(): List<String> =
        prefs.getString(KEY_RECENT, "")!!.split(",").filter { it.isNotBlank() }

    /** Membuka pemasang APK bawaan Android untuk file yang dipilih user. */
    fun installApk(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    fun openInstallPermissionSettings() {
        val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
            .setData(Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    companion object {
        private const val KEY_RECENT = "recent_packages"
        private const val MAX_RECENT = 8
    }
}
