# GameHub GameX

Game booster & launcher Android berbasis YAML. Tanpa root, tanpa Shizuku. Android 10 sampai 16.

## Struktur project

```
GameHubGameX/
├── settings.gradle.kts
├── build.gradle.kts
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/
        │   ├── gamehub.yml        <- konfigurasi utama (default)
        │   └── sparkler.png       <- wallpaper utama (full-screen)
        ├── java/com/gamehub/gamex/
        │   ├── ConfigManager.kt   <- parse, validasi, simpan, import/export YAML
        │   ├── SystemInfo.kt      <- RAM, CPU, storage, baterai, refresh rate
        │   ├── GameScanner.kt     <- deteksi game, launch, recently played, install APK
        │   └── MainActivity.kt    <- UI Compose: Home, Library, Performance, Settings
        └── res/values/themes.xml
```

## Cara kerja YAML

- Saat pertama dibuka, app menyalin `assets/gamehub.yml` ke penyimpanan lokal app.
- Semua pengaturan (nama, background, overlay, warna, navigasi, fitur, interval polling) dibaca dari file itu.
- Di menu **Settings** kamu bisa edit YAML langsung. Tombol **Validasi & Simpan** mengecek isinya dulu. Kalau salah, pesan error ditampilkan dan file lama tidak diubah.
- **Import** memuat file `.yml` dari penyimpanan HP. **Export** menyimpan config aktif ke file baru.
- Kalau YAML rusak saat app dibuka, layar error muncul dengan pesan jelasnya dan tombol **Pakai config default**.

Contoh error yang ditangkap:
- `YAML tidak valid: ...` (sintaks salah)
- `'ui.accent' harus format hex seperti #FF1744`
- `'background.overlay' harus di antara 0.0 dan 1.0`
- `Halaman 'Foo' tidak dikenal. Pilihan: Home, Library, Performance, Settings`

## Fitur

- Deteksi game terpasang (app dengan kategori game ditandai)
- Launch game dan daftar terakhir dimainkan
- Pilih file APK dan pasang lewat pemasang bawaan Android
- Monitor RAM, CPU (model, core, frekuensi maks jika terbaca), storage, baterai (level, status, suhu), refresh rate
- Import, export, dan reset konfigurasi YAML

## Build APK

1. Install **Android Studio** (Koala atau lebih baru) dengan JDK 17.
2. Buka folder `GameHubGameX` di Android Studio, tunggu Gradle sync selesai.
3. Pastikan `app/src/main/assets/sparkler.png` dan `gamehub.yml` ada.
4. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Hasil ada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Untuk release: **Build > Generate Signed App Bundle / APK**.

Atau dari terminal (setelah Gradle wrapper dibuat dengan `gradle wrapper`):

```bash
./gradlew assembleDebug
```

## Catatan batasan

- Tanpa root, app tidak bisa mengubah clock CPU/GPU atau mematikan proses sistem. Fitur "boost" yang realistis di sini adalah pemantauan, pemilihan profil, dan pengelolaan app.
- Membaca frekuensi CPU lewat sysfs bisa dibatasi oleh vendor HP. Kalau tidak terbaca, nilainya ditampilkan kosong.
- Saat config diubah dari editor Settings, komentar di YAML bisa hilang. Edit lewat editor tetap aman, hanya komentarnya tidak ikut tersimpan.
